# encoding: UTF-8
# Autor: Pedro Cortés Soberanes // A01374919
# Proyecto Final - Juego Snake

# Librerías
import pygame, time
from pygame.locals import *
from random import randint

# Dimensiones de la pantalla
ANCHO = 600
ALTO = 545
# Colores
BLANCO = (255,255,255)  # R,G,B en el rango [0,255]
ColorSnake = (0, 122, 0)
# X para colocar Fondos
x=0
# Sprites
NUM_IMAGENES = 10
TIEMPO_ENTRE_FRAMES = 0.1
TIEMPO_TOTAL = NUM_IMAGENES*TIEMPO_ENTRE_FRAMES

# Función que sirve para dibujar el menu inical
def dibujarMenu(ventana, botonJugar,imagenFondo):
    ventana.blit(botonJugar.image, botonJugar.rect)
    ventana.blit(imagenFondo, (x, 0))

# Función que sirve para dibujar la pantalla de juego
def dibujarJuego(ventana,imagenFondoJuego):
    ventana.blit(imagenFondoJuego, (x, 0))

# Función que sirve para dibujar la Vibora
def dibujarVibora(snake, ventana):
    for i in range(len(snake)):
        pygame.draw.rect(ventana, (ColorSnake), (snake[i][1] * 20, snake[i][0] * 20, 20, 20), 5)

# Función que sirve para hacer avanzar a la vibora
def avanzar(snake, nuevaPos):
    for i in reversed(range(1, len(snake))):
        snake[i] = snake[i - 1]
    snake[0] = nuevaPos
    return snake

# Función que sirve para dibujar la pantalla si es que perdiste
def dibujarPerdiste(ventana,imagenFondoPerdiste):
    ventana.blit(imagenFondoPerdiste, (x, 0))

# Función que sirve para crear una lista con los sprites
def crearListaSprites():
    lista = []

    for i in range(NUM_IMAGENES):
        nombre = "Sprites/s-"+str(i)+".png"
        imagen = pygame.image.load(nombre)
        sprAnimacion = pygame.sprite.Sprite()
        sprAnimacion.image = imagen
        sprAnimacion.rect = imagen.get_rect()
        sprAnimacion.rect.left = ANCHO//2-sprAnimacion.rect.width//2 -140
        sprAnimacion.rect.top = ALTO//2-sprAnimacion.rect.height//2 +115
        lista.append(sprAnimacion)
    return lista

# Función que sirve para las frames de los sprites
def obtenerFrame(timerAnimacion, listaSprites):
    indice = int(timerAnimacion/TIEMPO_ENTRE_FRAMES)
    return listaSprites[indice]

def dibujar():
    # Ejemplo del uso de pygame
    pygame.init()   # Inicializa pygame
    ventana = pygame.display.set_mode((ANCHO, ALTO))    # Crea la ventana de dibujo
    reloj = pygame.time.Clock()  # Para limitar los fps
    termina = False # Bandera para saber si termina la ejecución

    estado = "menu"  # jugando, fin

    # Cargar imagenes
    imgBtnJugar = pygame.image.load("imagenes/snake_play.png")

    # Sprite
    botonJugar = pygame.sprite.Sprite()
    botonJugar.image = imgBtnJugar
    botonJugar.rect = imgBtnJugar.get_rect()
    botonJugar.rect.left = ANCHO // 2 - botonJugar.rect.width // 2
    botonJugar.rect.top = ALTO // 2 - botonJugar.rect.height // 2

    #Fondos
    imagenFondo = pygame.image.load("imagenes/menu.png")
    imagenFondoJuego = pygame.image.load("imagenes/fondo_game.png")
    imagenFondoPerdiste = pygame.image.load("imagenes/game_over.png")

    #Snake Movimiento
    snake, limites = [[5, 7], [5, 6], [5, 5]], [5, 7, 5, 5]
    derecha, izquierda, arriba, abajo, rand1, rand2 = False, False, False, False, 10, 10
    R, G, B = 0, 0, 255

    # MUSICA de fondo
    pygame.mixer.init()
    pygame.mixer.music.load("musicaFondo.mp3")
    pygame.mixer.music.play(-1)

    # Animacion de Snake(Sprites)
    listaSprites = crearListaSprites()
    timerAnimacion = 0

    while not termina:
        # Procesa los eventos que recibe
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:  # El usuario hizo click en el botón de salir
                termina = True
            elif evento.type == pygame.MOUSEBUTTONDOWN:  # El usuario hizo click con mause
                xm, ym = pygame.mouse.get_pos()  # Leer posicion del mouse
                if estado == "menu":
                    xb, yb, anchoB, altoB = botonJugar.rect
                if xm >= xb and xm <= xb + anchoB:
                    if ym >= yb and ym <= yb + altoB:
                        # Cambiar de ventana
                        estado = "jugando"
            elif evento.type == KEYDOWN:
                if evento.key == K_DOWN and arriba == False:
                    abajo, arriba, derecha, izquierda = True, False, False, False
                elif evento.key == K_UP and abajo == False:
                    arriba, abajo, derecha, izquierda = True, False, False, False
                elif evento.key == K_RIGHT and izquierda == False:
                    derecha, arriba, abajo, izquierda = True, False, False, False
                elif evento.key == K_LEFT and derecha == False:
                    izquierda, arriba, derecha, abajo = True, False, False, False

        if snake[0][0] == rand2 and snake[0][1] == rand1:
            snake.append([0, 0])
            rand1, rand2, R, G, B = randint(1, 25), randint(1, 25), randint(10, 225), randint(10, 225), randint(10,225)

        for i in range(1, len(snake)):
            if snake[0][0] == snake[i][0] and snake[0][1] == snake[i][1]:
                estado = "perdiste"

        if derecha == True:
            snake = avanzar(snake, [snake[0][0], snake[0][1] + 1])
        elif izquierda == True:
            snake = avanzar(snake, [snake[0][0], snake[0][1] - 1])
        elif arriba == True:
            snake = avanzar(snake, [snake[0][0] - 1, snake[0][1]])
        elif abajo == True:
            snake = avanzar(snake, [snake[0][0] + 1, snake[0][1]])

        # Borrar pantalla
        ventana.fill(BLANCO)

        # Dibujar, aquí haces todos los trazos que requieras
        if estado == "menu":
            dibujarMenu(ventana,botonJugar,imagenFondo)
            frameActual = obtenerFrame(timerAnimacion, listaSprites)
            ventana.blit(frameActual.image, frameActual.rect)
        if estado == "jugando":
            dibujarJuego(ventana,imagenFondoJuego)
            dibujarVibora(snake, ventana)
            #Carnada
            pygame.draw.rect(ventana, (R, G, B, 0), (rand1 * 20, rand2 * 20, 20, 20))
        if estado == "perdiste":
            dibujarPerdiste(ventana, imagenFondoPerdiste)

        time.sleep(.1)
        pygame.display.update()   # Actualiza trazos
        timerAnimacion += reloj.tick(40) / 1000  # 40 fps
        if timerAnimacion >= TIEMPO_TOTAL:
            timerAnimacion = 0

    pygame.quit()   # termina pygame

def main():
    dibujar()
main()