# encoding: UTF-8
# Autor: Leonardo Castillejos Vite
# Juego en Pygame

import pygame
from random import randint
from pygame import*
pygame.init()

# Dimensiones de la pantalla
ANCHO = 600
ALTO = 600
# Colores
BLANCO = (255,255,255)  # R,G,B en el rango [0,255]
VERDE_BANDERA = (0, 122, 0)
ROJO = (255, 0, 0)


def dibujarMenu(ventana, btnJugar, btnScore):
    ventana.blit(btnJugar.image, btnJugar.rect)
    ventana.blit(btnScore.image, btnScore.rect)

def dibujarJuego(ventana,jugadorF, jugadorA, jugadorI, jugadorD, x, y, jugador, listabalasA, listabalasS, listabalasW, listabalasD, listaEnemigos):
    jugador.rect.left = x
    jugador.rect.top = y
    ventana.blit(jugador.image, jugador.rect)

    for bala in listabalasA:
        ventana.blit(bala.image, bala.rect)
    for bala in listabalasD:
        ventana.blit(bala.image, bala.rect)
    for bala in listabalasW:
        ventana.blit(bala.image, bala.rect)
    for bala in listabalasS:
        ventana.blit(bala.image, bala.rect)
    for enemigo in listaEnemigos:
        ventana.blit(enemigo.image, enemigo.rect)


def actualizarBalas(listaEnemigos, listaBalasS, listabalasA, listabalasW, listabalasD):
    for bala in listabalasD:
        bala.rect.left -= 20
    for bala in listaBalasS:
        bala.rect.left += 20
    for bala in listabalasW:
        bala.rect.top += 20
    for bala in listabalasA:
        bala.rect.top -= 20

    for k in range(-1, -len(listabalasD) - 1, -1):
        if listabalasD[k].rect.left <= -30:
            listabalasD.remove(listabalasD[k])
    for k in range(-1, -len(listaBalasS) - 1, -1):
        if listaBalasS[k].rect.left >= 616:
            listaBalasS.remove(listaBalasS[k])
    for k in range(-1, -len(listabalasW) - 1, -1):
        if listabalasW[k].rect.top >= 616:
            listabalasW.remove(listabalasW[k])
    for k in range(-1, -len(listabalasA) - 1, -1):
        if listabalasA[k].rect.top >= 616:
            listabalasA.remove(listabalasA[k])
    #Colisiones
    for bala in listabalasD:
        for enemigo in listaEnemigos:
            if bala.rect.colliderect(enemigo):
                listaEnemigos.remove(enemigo)
                listabalasD.remove(bala)
    for bala in listaBalasS:
        for enemigo in listaEnemigos:
            if bala.rect.colliderect(enemigo):
                listaEnemigos.remove(enemigo)
                listaBalasS.remove(bala)
    for bala in listabalasW:
        for enemigo in listaEnemigos:
            if bala.rect.colliderect(enemigo):
                listaEnemigos.remove(enemigo)
                listabalasW.remove(bala)
    for bala in listabalasA:
        for enemigo in listaEnemigos:
            if bala.rect.colliderect(enemigo):
                listaEnemigos.remove(enemigo)
                listabalasA.remove(bala)

def moverEnemigos(listaEnemigos, jugador, jugadorF, jugadorA, jugadorS, jugadorD, x, y, estado):
    for enemigo in listaEnemigos:
        if enemigo.rect.left < x:
            enemigo.rect.left += 4
        if enemigo.rect.left > x:
            enemigo.rect.left -= 4
        if enemigo.rect.top < y:
            enemigo.rect.top += 4
        if enemigo.rect.top > y:
            enemigo.rect.top -= 4

def pasarTiempo(ventana,minuto, segundo, texto, fuente):
    texto = fuente.render(("%d : %d" % (minuto, segundo)), False, (0, 255, 0))
    ventana.blit(texto, (0, 0))


def escribirFinal(ventana, fuente):
    texto = fuente.render("Game Over", False, (255, 0, 0))
    ventana.blit(texto, (150,150))


def generarEnemigos(listaEnemigos, imgEnemigo):
    lado = randint(1,5)
    if lado == 1:
        enemigo = pygame.sprite.Sprite()
        enemigo.image = imgEnemigo
        enemigo.rect = imgEnemigo.get_rect()
        enemigo.rect.left = randint(0, 601)
        enemigo.rect.top = 0
        listaEnemigos.append(enemigo)
    if lado == 2:
        enemigo = pygame.sprite.Sprite()
        enemigo.image = imgEnemigo
        enemigo.rect = imgEnemigo.get_rect()
        enemigo.rect.left = 0
        enemigo.rect.top = randint(0,601)
        listaEnemigos.append(enemigo)
    if lado == 3:
        enemigo = pygame.sprite.Sprite()
        enemigo.image = imgEnemigo
        enemigo.rect = imgEnemigo.get_rect()
        enemigo.rect.left = randint(0,601)
        enemigo.rect.top = 600
        listaEnemigos.append(enemigo)
    if lado == 4:
        enemigo = pygame.sprite.Sprite()
        enemigo.image = imgEnemigo
        enemigo.rect = imgEnemigo.get_rect()
        enemigo.rect.left = 600
        enemigo.rect.top = randint(0,601)
        listaEnemigos.append(enemigo)
    return listaEnemigos


def evaluarPuntuaciones(minuto, segundo):
    archivo = open("Scores.txt",encoding='UTF-8')
    lista = archivo.readlines()
    archivo.close()
    print(lista)
    tokens1 = lista[0].split(" ")
    score1 = tokens1[1].split(":")
    sec1 = score1[1].replace("\n", "")
    tokens2 = lista[1].split(" ")
    score2 = tokens2[1].split(":")
    sec2 = score2[1].replace("\n", "")
    tokens3 = lista[2].split(" ")
    score3 = tokens3[1].split(":")
    sec3 = score3[1].replace("\n", "")

    if minuto > int(score1[0]):
        lista[0:0] = ["1. %d:%d\n" % (minuto, segundo)]
        return lista
    elif minuto == int(score1[0]):
        if segundo > int(sec1):
            lista[0:0] = ["1. %d:%d\n" % (minuto, segundo)]
            return lista
        elif segundo == int(sec1):
            lista[1:1] = ["2. %d:%d\n" % (minuto, segundo)]
            return lista
        elif minuto > int(score2[0]):
            lista[1:1] = ["2. %d:%d\n" % (minuto, segundo)]
            return lista
        elif minuto == int(score2[0]):
            if segundo > int(sec2):
                lista[1:1] = ["2. %d:%d\n" % (minuto, segundo)]
                return lista
            elif segundo == int(sec2):
                lista[2:2] = ["3. %d:%d\n" % (minuto, segundo)]
                return lista
            elif minuto > int(score3[0]):
                lista[2:2] = ["3. %d:%d\n" % (minuto, segundo)]
                return lista
            elif minuto == int(score3[0]):
                if segundo > int(sec3):
                    lista[2:2] = ["3. %d:%d\n" % (minuto, segundo)]
                    return lista
    return lista

def escribirPuntuaciones(ventana, lista, fuente):
    score1 = lista[0].split(" ")
    score2 = lista[1].split(" ")
    score3 = lista[2].split(" ")
    texto1 = score1[1].replace("\n", "")
    texto2 = score2[1].replace("\n", "")
    texto3 = score3[1].replace("\n", "")
    archivo = open("Scores.txt", "w", encoding='UTF-8')
    archivo.write("1-" + " " + texto1 +'\n')
    archivo.write("2-" + " " + texto2 +'\n')
    archivo.write("3-" + " " + texto3 +'\n')
    archivo.close()
    escribe1 = fuente.render(("1-" + " " + texto1), False, (186,0,122))
    escribe2 = fuente.render(("2-" + " " + texto2), False, (160, 0, 122))
    escribe3 = fuente.render(("3-" + " " + texto3), False, (150, 0, 122))
    ventana.blit(escribe1,(220,120))
    ventana.blit(escribe2,(220,220))
    ventana.blit(escribe3,(220,320))







def dibujar():
    # Ejemplo del uso de pygame
    pygame.init()   # Inicializa pygame
    ventana = pygame.display.set_mode((ANCHO, ALTO))    # Crea la ventana de dibujo
    reloj = pygame.time.Clock() # Para limitar los fps
    termina = False # Bandera para saber si termina la ejecución

    #Estados
    estado = "menu"

    #Botones
    imgButtonJugar = pygame.image.load("button_jugar.png")
    ButtonJugar = pygame.sprite.Sprite()
    ButtonJugar.image = imgButtonJugar
    ButtonJugar.rect = imgButtonJugar.get_rect()
    ButtonJugar.rect.left = ANCHO // 2 - ButtonJugar.rect.width // 2
    ButtonJugar.rect.top = 200 - ButtonJugar.rect.height // 2
    imgButtonScore = pygame.image.load("button_high-scores.png")
    ButtonScore = pygame.sprite.Sprite()
    ButtonScore.image = imgButtonScore
    ButtonScore.rect = imgButtonScore.get_rect()
    ButtonScore.rect.left = ANCHO // 2 - ButtonScore.rect.width // 2
    ButtonScore.rect.top = 400 - ButtonScore.rect.height // 2

    # Enemigos
    imgEnemigo = pygame.image.load("Enemigo.png")


    listaEnemigos = []

    # balas
    imgBala = pygame.image.load("Disparo.png")
    listaBalasA = []
    listaBalasS = []
    listaBalasW = []
    listaBalasD = []

    #Jugador
    imgJugadorDer = pygame.image.load("spaceshipD.png")
    jugadorDer = pygame.sprite.Sprite()
    jugadorDer.image = imgJugadorDer
    jugadorDer.rect = imgJugadorDer.get_rect()
    #jugadorDer.rect.left = ANCHO//2 - jugadorDer.rect.width//2
    #jugadorDer.rect.top = ALTO//2 - jugadorDer.rect.height // 2

    imgJugadorIzq = pygame.image.load("spaceshipI.png")
    jugadorIzq = pygame.sprite.Sprite()
    jugadorIzq.image = imgJugadorIzq
    jugadorIzq.rect = imgJugadorIzq.get_rect()

    '''
    imgJugadorIzq = pygame.image.load("spaceshipI.png")
    jugadorIzq = pygame.sprite.Sprite()
    jugadorIzq = imgJugadorIzq
    jugadorIzq.rect = imgJugadorIzq.get_rect()
    '''

    imgJugadorFre = pygame.image.load("spaceshipF.png")
    jugadorFre = pygame.sprite.Sprite()
    jugadorFre.image = imgJugadorFre
    jugadorFre.rect = imgJugadorFre.get_rect()

    imgJugadorEsp = pygame.image.load("spaceshipA.png")
    jugadorEsp = pygame.sprite.Sprite()
    jugadorEsp.image = imgJugadorEsp
    jugadorEsp.rect = imgJugadorEsp.get_rect()

    #Condiciones iniciales
    x = ANCHO//2 - jugadorFre.rect.width//2
    y = ALTO//2 - jugadorFre.rect.height//2
    jugador = jugadorFre

    # Fuente
    pygame.font.init()
    fuente = pygame.font.SysFont('Comic Sans MS', 20)
    fuente2 = pygame.font.SysFont('Comic Sans MS', 54, True)


    timer = 0
    timerDisparo = 0
    timerTiempo = 0
    timerFinal = 0
    segundo = 0
    minuto = 0
    contador = 0
    puntuaciones = []

    texto = fuente.render(("%d : %d" %(minuto, segundo)), False, (0,255,0))
    imagen_fondo = pygame.image.load("fondo.jpg")




    while not termina:
        # Procesa los eventos que recibe
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:  # El usuario hizo click en el botón de salir
                termina = True
            elif evento.type == pygame.MOUSEBUTTONDOWN:
                xm, ym = pygame.mouse.get_pos()
                if estado == "menu":
                    xb, yb, anchoB, altoB = ButtonJugar.rect
                    xs, ys, anchoS, altoS = ButtonScore.rect
                    if xm >= xb and xm <= xb + anchoB:
                        if ym >= yb and ym <= yb + altoB:
                            estado = "jugando"
                    if xm >= xs and xm <= xs + anchoS:
                        if ym >= ys and ym <= ys + altoS:
                            estado = "Scores"
            elif estado == "jugando":
                if evento.type == pygame.KEYDOWN:
                    if evento.key == pygame.K_s:
                        if y <= 580:
                            jugador = jugadorFre
                            y += 5
                    elif evento.key == pygame.K_w:
                        if y >= 20:
                            jugador = jugadorEsp
                            y -= 5
                    elif evento.key == pygame.K_a:
                        if x >= 20:
                            jugador = jugadorIzq
                            x -= 5
                    elif evento.key == pygame.K_d:
                        if x <= 580:
                            jugador = jugadorDer
                            x += 5
                    if timerDisparo >= .6:
                        if evento.key == pygame.K_LEFT:
                            bala = pygame.sprite.Sprite()
                            bala.image = imgBala
                            bala.rect = imgBala.get_rect()
                            bala.rect.left = x + jugador.rect.width//2
                            bala.rect.top = y + jugador.rect.height//2
                            listaBalasA.append(bala)
                            timerDisparo = 0
                        elif evento.key == pygame.K_DOWN:
                            bala = pygame.sprite.Sprite()
                            bala.image = imgBala
                            bala.rect = imgBala.get_rect()
                            bala.rect.left = x + jugador.rect.width // 2
                            bala.rect.top = y + jugador.rect.height // 2
                            listaBalasS.append(bala)
                            timerDisparo = 0
                        elif evento.key == pygame.K_UP:
                            bala = pygame.sprite.Sprite()
                            bala.image = imgBala
                            bala.rect = imgBala.get_rect()
                            bala.rect.left = x + jugador.rect.width // 2
                            bala.rect.top = y + jugador.rect.height // 2
                            listaBalasW.append(bala)
                            timerDisparo = 0
                        elif evento.key == pygame.K_RIGHT:
                            bala = pygame.sprite.Sprite()
                            bala.image = imgBala
                            bala.rect = imgBala.get_rect()
                            bala.rect.left = x + jugador.rect.width // 2
                            bala.rect.top = y + jugador.rect.height // 2
                            listaBalasD.append(bala)
                            timerDisparo = 0




        # Borrar pantalla
        ventana.blit(imagen_fondo,(0,0))

        timer += 1/40
        timerDisparo += 1/40

        # Dibujar, aquí haces todos los trazos que requieras
        if estado == "menu":
            dibujarMenu(ventana, ButtonJugar ,ButtonScore)

        elif estado == "jugando":
            dibujarJuego(ventana, jugadorFre, jugadorEsp, jugadorIzq, jugadorDer,x,y, jugador, listaBalasA, listaBalasD, listaBalasS, listaBalasW, listaEnemigos)
            timerTiempo += 1/40
            if timerTiempo >= 1:
                segundo += 1
                timerTiempo = 0
                if segundo == 60:
                    minuto += 1
                    segundo = 0
            pasarTiempo(ventana, minuto, segundo, texto, fuente)
            if timer >= 1:
                generarEnemigos(listaEnemigos, imgEnemigo)
                timer = 0
            actualizarBalas(listaEnemigos, listaBalasD, listaBalasW, listaBalasS, listaBalasA)
            moverEnemigos(listaEnemigos, jugador, jugadorDer, jugadorIzq, jugadorEsp, jugadorFre, x, y, estado)
            for enemigos in listaEnemigos:
                if enemigos.rect.colliderect(jugador):
                    estado = "Over"
        elif estado == "Over":
            escribirFinal(ventana, fuente2)
            timerFinal += 1/40
            if timerFinal >= 3:
                estado = "Scores"
        elif estado == "Scores":
            if contador < 1:
                puntuaciones = evaluarPuntuaciones(minuto, segundo)
                contador += 1
            escribirPuntuaciones(ventana, puntuaciones, fuente2)


        pygame.display.flip()  # Actualiza trazos
        reloj.tick(40)  # 40 fps

    pygame.quit()  # termina pygame

def main():
    dibujar()

main()