# encoding: UTF-8
# Autor: Arianna Sinai Soriano Vega
# Proyecto Final, Crazy Snakes

import pygame
from random import randint

# Dimensiones de la pantalla
ANCHO = 800
ALTO = 600
# Colores
BLANCO = (255,255,255)  # R,G,B en el rango [0,255]
VERDE = (136, 176, 175)
ROJO = (242, 85, 44)
NEGRO=(0,0,0)
AMARILLO=(254,250,2)
AMARILLOCLARO=(246,209,85)
ROSA=(206,51,117)
AZUL=(150,223,228)
GRIS=(180,180,180)
COLOR=(0,0,0)
# POSICIONES DE SNAKES
SNAKEEQUISDOS=ANCHO//2-40
SNAKEYEDOS=ALTO//2
SNAKEEQUIS = ANCHO // 2 - 40
SNAKEYE = ALTO // 2
SNAKEEQUISTRES=ANCHO//2+30
SNAKEYETRES=ALTO//2
SNAKEEQUISIA=ANCHO//2+30
SNAKEYEIA=ALTO//2
#Contador de tiempo
GAMETIME=0
GAMETIME2=0
# Direccion de snake
dir=1
dir2=1
dir3=1

#MARCADOR
MARCA=0
MARCA2=0
MARCA3=0
# lista de comida
lista=[]
#Direcciones
ARRIBA=1
ABAJO=2
DERECHA=3
IZQ=4
puntos2=0
puntos3=0
puntos1=0

entrada = open("puntosMaximos.txt", "r", encoding='UTF-8')
contenido = entrada.readline()
entrada.close()
puntosMAXI = 0


# MENU
def dibujarMenu(ventana,Multi,UnJugador,Titulo,Puntos,Salir):

    ventana.blit(Titulo.image, (Titulo.rect.left, ALTO // 9))
    ventana.blit(Puntos.image,(Puntos.rect.left, ALTO//2+10))
    ventana.blit(UnJugador.image, (UnJugador.rect.left, UnJugador.rect.top // 3 + 140))
    ventana.blit(Multi.image, (Multi.rect.left, Multi.rect.top // 3 + 300))
    ventana.blit(Salir.image, (ANCHO - 150, ALTO - 100, 120, 80))

# Dibujar Pantallas de selección de color
def datosJugador(ventana,Escoger,Salir):

    ventana.blit(Escoger.image, (Escoger.rect.left, ALTO // 9))
    pygame.draw.rect(ventana,ROSA,(ANCHO//2-240,ALTO//2-40,80,80))
    pygame.draw.rect(ventana, ROJO, (ANCHO // 2 - 140, ALTO // 2-40, 80, 80))
    pygame.draw.rect(ventana, AMARILLOCLARO, (ANCHO // 2-40, ALTO // 2-40, 80, 80))
    pygame.draw.rect(ventana, VERDE, (ANCHO // 2 +60, ALTO // 2-40, 80, 80))
    pygame.draw.rect(ventana, AZUL, (ANCHO // 2 + 160, ALTO // 2-40, 80, 80))
    ventana.blit(Salir.image, (ANCHO - 150, ALTO - 100))

def datosJugador2(ventana, Escoger,Salir,Uno):

        ventana.blit(Escoger.image, (Escoger.rect.left, ALTO // 12-10))
        ventana.blit(Uno.image, (Uno.rect.left, ALTO // 5+15))
        pygame.draw.rect(ventana, ROSA, (ANCHO // 2 - 240, ALTO // 2 - 100, 80, 80))
        pygame.draw.rect(ventana, ROJO, (ANCHO // 2 - 140, ALTO // 2 - 100, 80, 80))
        pygame.draw.rect(ventana, AMARILLOCLARO, (ANCHO // 2 - 40, ALTO // 2 - 100, 80, 80))
        pygame.draw.rect(ventana, VERDE, (ANCHO // 2 + 60, ALTO // 2 - 100, 80, 80))
        pygame.draw.rect(ventana, AZUL, (ANCHO // 2 + 160, ALTO // 2 - 100, 80, 80))
        ventana.blit(Salir.image, (ANCHO - 150, ALTO - 100, 120, 80))

def datosJugador3(ventana, Escoger,COLOR,Reg,Uno,Dos):
    ventana.blit(Uno.image, (Uno.rect.left, ALTO // 5 + 15))
    ventana.blit(Dos.image, (Dos.rect.left, ALTO // 2+35))
    if COLOR == ROSA:
        pygame.draw.rect(ventana, ROJO, (ANCHO // 2 - 190, ALTO // 2 + 100, 80, 80))
        pygame.draw.rect(ventana, AMARILLOCLARO, (ANCHO // 2 -90, ALTO // 2 + 100, 80, 80))
        pygame.draw.rect(ventana, VERDE, (ANCHO // 2 + 10, ALTO // 2 + 100, 80, 80))
        pygame.draw.rect(ventana, AZUL, (ANCHO // 2 + 110, ALTO // 2 + 100, 80, 80))
    elif COLOR == ROJO:
        pygame.draw.rect(ventana, ROSA, (ANCHO // 2 - 190, ALTO // 2 + 100, 80, 80))
        pygame.draw.rect(ventana, AMARILLOCLARO, (ANCHO // 2-90, ALTO // 2 + 100, 80, 80))
        pygame.draw.rect(ventana, VERDE, (ANCHO // 2 + 10, ALTO // 2 + 100, 80, 80))
        pygame.draw.rect(ventana, AZUL, (ANCHO // 2 + 110, ALTO // 2 + 100, 80, 80))
    elif COLOR == AMARILLOCLARO:
        pygame.draw.rect(ventana, ROSA, (ANCHO // 2 - 190, ALTO // 2 + 100, 80, 80))
        pygame.draw.rect(ventana, ROJO, (ANCHO // 2-90, ALTO // 2 + 100, 80, 80))
        pygame.draw.rect(ventana, VERDE, (ANCHO // 2 + 10, ALTO // 2 + 100, 80, 80))
        pygame.draw.rect(ventana, AZUL, (ANCHO // 2 + 110, ALTO // 2 + 100, 80, 80))
    elif COLOR == VERDE:
        pygame.draw.rect(ventana, ROSA, (ANCHO // 2 - 190, ALTO // 2 + 100, 80, 80))
        pygame.draw.rect(ventana, ROJO, (ANCHO // 2-90, ALTO // 2 + 100, 80, 80))
        pygame.draw.rect(ventana, AMARILLOCLARO, (ANCHO // 2 + 10, ALTO // 2 + 100, 80, 80))
        pygame.draw.rect(ventana, AZUL, (ANCHO // 2 + 110, ALTO // 2 + 100, 80, 80))
    elif COLOR == AZUL:
        pygame.draw.rect(ventana, ROSA, (ANCHO // 2 - 190, ALTO // 2 + 100, 80, 80))
        pygame.draw.rect(ventana, ROJO, (ANCHO // 2-90, ALTO // 2 + 100, 80, 80))
        pygame.draw.rect(ventana, AMARILLOCLARO, (ANCHO // 2 + 10, ALTO // 2 + 100, 80, 80))
        pygame.draw.rect(ventana, VERDE, (ANCHO // 2 + 110, ALTO // 2 + 100, 80, 80))

    ventana.blit(Escoger.image, (Escoger.rect.left, ALTO // 12 - 10))
    pygame.draw.rect(ventana, ROSA, (ANCHO // 2 - 240, ALTO // 2- 100, 80, 80))
    pygame.draw.rect(ventana, ROJO, (ANCHO // 2 - 140, ALTO // 2 - 100, 80, 80))
    pygame.draw.rect(ventana, AMARILLOCLARO, (ANCHO // 2 - 40, ALTO // 2 - 100, 80, 80))
    pygame.draw.rect(ventana, VERDE, (ANCHO // 2 + 60, ALTO // 2 - 100, 80, 80))
    pygame.draw.rect(ventana, AZUL, (ANCHO // 2 + 160, ALTO // 2 - 100, 80, 80))
    ventana.blit(Reg.image, (ANCHO - 300, ALTO - 100))
# Dibujar pantalla de juego

def dibujarJugando1(ventana,COLOR,Salir):

    for i in range (0,371,10):
        pygame.draw.line(ventana,GRIS,(30,ALTO//5+i),(ANCHO-30,ALTO//5+i),1)
        pygame.draw.line(ventana, GRIS, (30+i, ALTO // 5 ), ( 30+i, ALTO-110 ), 1)
        pygame.draw.line(ventana, GRIS, (ANCHO-30 - i, ALTO // 5), (ANCHO-30 - i, ALTO - 110), 1)

    pygame.draw.rect(ventana,AMARILLO,(ANCHO//2-60,10,120,80))

    pygame.draw.rect(ventana,COLOR,(30,10,120,80))
    # pygame.draw.rect(ventana,BLANCO,(ANCHO-150,10,120,80))

    pygame.draw.rect(ventana, COLOR, (160, 10, 120, 80))
    # pygame.draw.rect(ventana, BLANCO, (ANCHO - 280, 10, 120, 80))

    pygame.draw.rect(ventana, AMARILLO, (30, ALTO-90, 120, 80))
    ventana.blit(Salir.image, (ANCHO - 150, ALTO - 100))


def dibujarJugando2(ventana,COLOR,COLOR2,Salir):
    for i in range (0,371,10):
        pygame.draw.line(ventana,GRIS,(30,ALTO//5+i),(ANCHO-30,ALTO//5+i),1)
        pygame.draw.line(ventana, GRIS, (30+i, ALTO // 5 ), ( 30+i, ALTO-110 ), 1)
        pygame.draw.line(ventana, GRIS, (ANCHO-30 - i, ALTO // 5), (ANCHO-30 - i, ALTO - 110), 1)

    pygame.draw.rect(ventana,AMARILLO,(ANCHO//2-60,10,120,80))

    pygame.draw.rect(ventana,COLOR,(30,10,120,80))
    pygame.draw.rect(ventana,COLOR2,(ANCHO-150,10,120,80))

    pygame.draw.rect(ventana, COLOR, (160, 10, 120, 80))
    pygame.draw.rect(ventana, COLOR2, (ANCHO - 280, 10, 120, 80))

    ventana.blit(Salir.image, (ANCHO - 150, ALTO - 100))


# Dibujar SNAKES

def dibujarSnake(ventana,dir,COLOR,listaSnake,listaSnake2,rondita,estado):
    global SNAKEEQUIS
    global SNAKEYE

    if SNAKEEQUIS<=760 and SNAKEEQUIS>=30 and SNAKEYE<=480 and SNAKEYE>=ALTO//5:
        pygame.draw.rect(ventana, COLOR, (SNAKEEQUIS + 1, SNAKEYE + 1, 9, 9))

        if dir == 0:
            SNAKEEQUIS +=10
        elif dir == 90:
            SNAKEYE += 10
        elif dir == 180:
            SNAKEEQUIS -= 10
        elif dir == 270:
            SNAKEYE -= 10


        '''
        if dir != 1:
            listaSnake.append([SNAKEEQUIS, SNAKEYE])
            listaSnake2 = listaSnake[:]
            listaSnake2.reverse()
            del listaSnake2[0]

        
        if len(listaSnake) > 3:

            for i in listaSnake2:
                if i[0] == SNAKEEQUIS and i[1] == SNAKEYE:
                    rondita+=1
                    estado = "ganador"
                    print(estado)
                else:
                    continue

        '''
    else:
        rondita += 1
        estado="ganador"
        print(estado)

def IA (ventana,listaSnake,dirIA,listaIA,listaIA2,dir):
    global SNAKEEQUISIA
    global SNAKEYEIA
    print(dirIA)

    if dir != 1:


        if SNAKEEQUISIA <= 760 and SNAKEEQUISIA >= 30 and SNAKEYEIA <= 480 and SNAKEYEIA >= ALTO // 5:
            pygame.draw.rect(ventana, BLANCO, (SNAKEEQUISIA + 1, SNAKEYEIA + 1, 9, 9))
            if dirIA == 1:
                SNAKEYEIA -= 10
                if len(listaIA) > 3:
                    for i in listaIA2:
                        if i[0] == SNAKEEQUISIA and i[1] == SNAKEYEIA:
                            dirIA = randint(DERECHA, IZQ)

            elif dirIA == 2:
                SNAKEYEIA += 10

                if len(listaIA) > 3:
                    for i in listaIA2:
                        if i[0] == SNAKEEQUISIA and i[1] == SNAKEYEIA:
                            dirIA = randint(DERECHA, IZQ)

            elif dirIA == 3:
                SNAKEEQUISIA += 10
                if len(listaIA) > 3:
                    for i in listaIA2:
                        if i[0] == SNAKEEQUISIA and i[1] == SNAKEYEIA:
                            dirIA = 1
                if SNAKEEQUISIA == 760 and SNAKEYEIA == 470:
                    dirIA = 1
                elif SNAKEEQUISIA == 760:
                    print("ca")
                    dirIA = 2

            elif dirIA == 4:
                SNAKEEQUISIA -= 10
                if len(listaIA) > 3:
                    for i in listaIA:
                        if i[0] == SNAKEEQUISIA and i[1] == SNAKEYEIA:
                            dirIA = randint(ARRIBA, ABAJO)







        if dirIA != 0:
            listaIA.append([SNAKEEQUISIA, SNAKEYEIA])
            listaIA2 = listaIA[:]
            listaIA2.reverse()
            del listaIA2[0]

        '''
        if len(listaIA) > 3:
            for i in listaIA2:
                if i[0] == SNAKEEQUISIA and i[1] == SNAKEYEIA:
                    print("mori222")
                else:
                    continue

        '''

def dibujarSnake2(ventana, dir2,dir3, COLOR2,COLOR,rondita):
    global SNAKEEQUISDOS
    global SNAKEYEDOS
    global SNAKEEQUISTRES
    global SNAKEYETRES
    if SNAKEEQUISDOS <= 760 and SNAKEEQUISDOS >= 30 and SNAKEYEDOS <= 480 and SNAKEYEDOS >= ALTO // 5:
        pygame.draw.rect(ventana, COLOR, (SNAKEEQUISDOS + 1, SNAKEYEDOS + 1, 9, 9))

        if dir2 == 0:
            SNAKEEQUISDOS += 10
        elif dir2 == 90:
            SNAKEYEDOS += 10
        elif dir2 == 180:
            SNAKEEQUISDOS -= 10
        elif dir2 == 270:
            SNAKEYEDOS -= 10

    else:
        rondita += 1
        estado = "ganador"
        print(estado)

    if SNAKEEQUISTRES <= 760 and SNAKEEQUISTRES >= 30 and SNAKEYETRES <= 480 and SNAKEYETRES >= ALTO // 5:
        pygame.draw.rect(ventana, COLOR2, (SNAKEEQUISTRES + 1, SNAKEYETRES + 1, 9, 9))

        if dir3 == 0:
            SNAKEEQUISTRES += 10
        elif dir3 == 90:
            SNAKEYETRES -= 10
        elif dir3 == 180:
            SNAKEEQUISTRES -= 10
        elif dir3 == 270:
            SNAKEYETRES += 10

    else:
        rondita += 1
        estado = "ganador"
        print(estado)


# MARCADORES
def marcadores(ventana,listaSnake,listaSnake2,MARCA,estado,COLOR,rondita,comidita,listaSnake3,MARCA2,MARCA3):


    if estado=="menu":
        # Puntos Maximos

        fuenteMax = pygame.font.SysFont('Arial', 44)

        Maxi = fuenteMax.render(str(contenido), 1,BLANCO)  # pygame.draw.rect(ventana, AMARILLO, (ANCHO // 2 - 60, 10, 120, 80))


        ventana.blit(Maxi, (ANCHO//2-10, ALTO // 2 +40))

    elif estado=="jugando1":
        puns = int(len(listaSnake) + (comidita * 10))

        pygame.draw.rect(ventana, AMARILLO, (ANCHO // 2 - 60, 10, 120, 80))

        pygame.draw.rect(ventana, COLOR, (30, 10, 120, 80))
        # pygame.draw.rect(ventana, BLANCO, (ANCHO - 150, 10, 120, 80))

        pygame.draw.rect(ventana, COLOR, (160, 10, 120, 80))
        # pygame.draw.rect(ventana, BLANCO, (ANCHO - 280, 10, 120, 80))

        pygame.draw.rect(ventana, AMARILLO, (30, ALTO - 90, 120, 80))
        # RONDA
        fuente = pygame.font.SysFont('Arial', 44)
        ronda = fuente.render("RONDA", 1, NEGRO)  # pygame.draw.rect(ventana, AMARILLO, (ANCHO // 2 - 60, 10, 120, 80))
        numeroRonda = fuente.render(str(rondita),1, NEGRO)

        # PUNTOS
        fuente3 = pygame.font.SysFont('Arial', 40)
        puntos = fuente3.render("PUNTOS", 1,
                                BLANCO)  # pygame.draw.rect(ventana, AMARILLO, (ANCHO // 2 - 60, 10, 120, 80))
        numeroPuntos = fuente3.render(str(puns), 1, BLANCO)

        puntos2 = fuente3.render("PUNTOS", 1,
                                 NEGRO)  # pygame.draw.rect(ventana, AMARILLO, (ANCHO // 2 - 60, 10, 120, 80))
        numeroPuntos2 = fuente3.render(str(puns), 1, NEGRO)

        # JUGADORES
        # fuenteIA = pygame.font.SysFont('Arial', 60)
        # IALetrero = fuenteIA.render("IA", 1, NEGRO)  # pygame.draw.rect(ventana, BLANCO, (ANCHO - 150, 10, 120, 80))

        fuenteS1 = pygame.font.SysFont('Arial', 42)
        S1Letrero = fuenteS1.render("SNAKE1", 1, BLANCO)  # pygame.draw.rect(ventana, BLANCO, (ANCHO - 150, 10, 120, 80))

        # BOOST
        fuenteBoost = pygame.font.SysFont('Arial', 32)
        BoostLetrero = fuenteBoost.render("Presiona R", 1,
                                          NEGRO)  # pygame.draw.rect(ventana, AMARILLO, (30, ALTO - 90, 120, 80))
        BoostLetrero2 = fuenteBoost.render("¡BONUS!", 1,
                                           NEGRO)  # pygame.draw.rect(ventana, AMARILLO, (30, ALTO - 90, 120, 80))

        # BLITS
        ventana.blit(ronda, (ANCHO // 2 - 56, 18))
        ventana.blit(numeroRonda, (ANCHO // 2 - 10, 50))
        # ventana.blit(IALetrero, (ANCHO - 110, 30))
        ventana.blit(S1Letrero, (30, 35))

        ventana.blit(BoostLetrero, (32, ALTO - 75))  # pygame.draw.rect(ventana, AMARILLO, (30, ALTO - 90, 120, 80))
        ventana.blit(BoostLetrero2, (50, ALTO - 45))  # pygame.draw.rect(ventana, AMARILLO, (30, ALTO - 90, 120, 80))

        ventana.blit(puntos, (160, 20))  # pygame.draw.rect(ventana, COLOR, (160, 10, 120, 80))
        ventana.blit(numeroPuntos, (210, 50))  # pygame.draw.rect(ventana, COLOR, (160, 10, 120, 80))

        # ventana.blit(puntos2, (ANCHO - 280, 20))  # pygame.draw.rect(ventana, BLANCO, (ANCHO - 280, 10, 120, 80))
        # ventana.blit(numeroPuntos2, (ANCHO - 230, 50))  # pygame.draw.rect(ventana, BLANCO, (ANCHO - 280, 10, 120, 80))

    elif estado=="jugando2":
        puns2 = int(len(listaSnake2) )
        puns3 = int(len(listaSnake3) )

        pygame.draw.rect(ventana, AMARILLO, (ANCHO // 2 - 60, 10, 120, 80))

        pygame.draw.rect(ventana, COLOR, (30, 10, 120, 80))
        pygame.draw.rect(ventana, BLANCO, (ANCHO - 150, 10, 120, 80))

        pygame.draw.rect(ventana, COLOR, (160, 10, 120, 80))
        pygame.draw.rect(ventana, BLANCO, (ANCHO - 280, 10, 120, 80))

        # RONDA
        fuente = pygame.font.SysFont('Arial', 44)
        ronda = fuente.render("RONDA", 1, NEGRO)  # pygame.draw.rect(ventana, AMARILLO, (ANCHO // 2 - 60, 10, 120, 80))
        numeroRonda = fuente.render(str(rondita), 1, NEGRO)

        # PUNTOS
        fuente3 = pygame.font.SysFont('Arial', 40)
        puntos = fuente3.render("PUNTOS", 1,
                                BLANCO)  # pygame.draw.rect(ventana, AMARILLO, (ANCHO // 2 - 60, 10, 120, 80))
        numeroPuntos = fuente3.render(str(MARCA2), 1, BLANCO)

        puntos2 = fuente3.render("PUNTOS", 1,
                                 NEGRO)  # pygame.draw.rect(ventana, AMARILLO, (ANCHO // 2 - 60, 10, 120, 80))
        numeroPuntos2 = fuente3.render(str(MARCA3), 1, NEGRO)

        # JUGADORES
        fuenteIA = pygame.font.SysFont('Arial', 42)
        IALetrero = fuenteIA.render("SNAKE2", 1, NEGRO)  # pygame.draw.rect(ventana, BLANCO, (ANCHO - 150, 10, 120, 80))

        fuenteS1 = pygame.font.SysFont('Arial', 42)
        S1Letrero = fuenteS1.render("SNAKE1", 1,
                                    BLANCO)  # pygame.draw.rect(ventana, BLANCO, (ANCHO - 150, 10, 120, 80))


        # BLITS
        ventana.blit(ronda, (ANCHO // 2 - 56, 18))
        ventana.blit(numeroRonda, (ANCHO // 2 - 10, 50))
        ventana.blit(IALetrero, (ANCHO - 150, 35))
        ventana.blit(S1Letrero, (30, 35))

        ventana.blit(puntos, (160, 20))  # pygame.draw.rect(ventana, COLOR, (160, 10, 120, 80))
        ventana.blit(numeroPuntos, (210, 50))  # pygame.draw.rect(ventana, COLOR, (160, 10, 120, 80))

        ventana.blit(puntos2, (ANCHO - 280, 20))  # pygame.draw.rect(ventana, BLANCO, (ANCHO - 280, 10, 120, 80))
        ventana.blit(numeroPuntos2, (ANCHO - 230, 50))  # pygame.draw.rect(ventana, BLANCO, (ANCHO - 280, 10, 120, 80))




# Ventanas GANADOR
def ganador(ventana,Gana,Salir,Otra,rondita,Continu,Pesdt,Gnst,winner,Best,estado,puntosMAXI,MARCA2,MARCA3):
    global puntos3
    global puntos2
    global puntos1
    if winner ==2:
        if rondita != 3:
            if winner == 2:
                ventana.blit(Pesdt.image, (Pesdt.rect.left, ALTO // 2 - 90))
                ventana.blit(Continu.image, (Continu.rect.left, ALTO - 100))
                ventana.blit(Salir.image, (ANCHO - 150, ALTO - 100))

        elif rondita == 3:
            ventana.blit(Best.image, (Best.rect.left, ALTO // 9))
            pygame.draw.rect(ventana,NEGRO,(ANCHO//2-200,ALTO//2-100,401,201))

            # PUNTOSMAX
            puntitos = pygame.font.SysFont('Arial', 80)
            MAXI = puntitos.render(str(puntosMAXI), 1,BLANCO)
            ventana.blit(MAXI, (ANCHO // 2 - 10,ALTO//2))

            # BLITS
            ventana.blit(Salir.image, (ANCHO - 150, ALTO - 100))
            ventana.blit(Otra.image, (150, ALTO - 100))



    elif winner == 1 and MARCA2!=2 and MARCA3!=2:
        if rondita != 3 and MARCA2!=2 and MARCA3!=2:
            ventana.blit(Gnst.image, (Gnst.rect.left, ALTO // 9))
            ventana.blit(Continu.image, (Continu.rect.left, ALTO - 100))
            ventana.blit(Salir.image, (ANCHO - 150, ALTO - 100))
            pygame.draw.rect(ventana, NEGRO, (ANCHO // 2 - 200, ALTO // 2 - 100, 401, 201))

            # PUNTOSMAX
            puntitos = pygame.font.SysFont('Arial', 80)
            MAXI = puntitos.render("JUGADOR 1", 1, BLANCO)
            ventana.blit(MAXI, (ANCHO // 2 - 154, ALTO // 2-26))
        elif rondita == 3:
            ventana.blit(Gnst.image, (Gnst.rect.left, ALTO // 9))
            ventana.blit(Salir.image, (ANCHO - 150, ALTO - 100))
            pygame.draw.rect(ventana, NEGRO, (ANCHO // 2 - 200, ALTO // 2 - 100, 401, 201))

            # PUNTOSMAX
            puntitos = pygame.font.SysFont('Arial', 80)
            MAXI = puntitos.render("JUGADOR 1", 1, BLANCO)
            ventana.blit(MAXI, (ANCHO // 2 - 154, ALTO // 2 - 26))
            ventana.blit(Otra.image, (150, ALTO - 100))


    elif winner == 3 and MARCA2!=2 and MARCA3!=2:
        if rondita != 3:
            ventana.blit(Gnst.image, (Gnst.rect.left, ALTO // 9))
            ventana.blit(Continu.image, (Continu.rect.left, ALTO - 100))
            ventana.blit(Salir.image, (ANCHO - 150, ALTO - 100))
            pygame.draw.rect(ventana, NEGRO, (ANCHO // 2 - 200, ALTO // 2 - 100, 401, 201))

            # PUNTOSMAX
            puntitos = pygame.font.SysFont('Arial', 80)
            MAXI = puntitos.render("JUGADOR 2", 1, BLANCO)
            ventana.blit(MAXI, (ANCHO // 2 - 154, ALTO // 2-26))
        elif rondita==3:
            ventana.blit(Gnst.image, (Gnst.rect.left, ALTO // 9))
            ventana.blit(Salir.image, (ANCHO - 150, ALTO - 100))
            pygame.draw.rect(ventana, NEGRO, (ANCHO // 2 - 200, ALTO // 2 - 100, 401, 201))

            # PUNTOSMAX
            puntitos = pygame.font.SysFont('Arial', 80)
            MAXI = puntitos.render("JUGADOR 2", 1, BLANCO)
            ventana.blit(MAXI, (ANCHO // 2 - 154, ALTO // 2 - 26))
            ventana.blit(Otra.image, (150, ALTO - 100))



    elif MARCA2 == 2:
        ventana.blit(Gnst.image, (Gnst.rect.left, ALTO // 9))
        ventana.blit(Salir.image, (ANCHO - 150, ALTO - 100))
        pygame.draw.rect(ventana, NEGRO, (ANCHO // 2 - 200, ALTO // 2 - 100, 401, 201))

        # PUNTOSMAX
        puntitos = pygame.font.SysFont('Arial', 80)
        MAXI = puntitos.render("JUGADOR 1", 1, BLANCO)
        ventana.blit(MAXI, (ANCHO // 2 - 154, ALTO // 2 - 26))
        ventana.blit(Otra.image, (150, ALTO - 100))
        MARCA3=0
        MARCA2=0

    elif MARCA3 == 2:
        ventana.blit(Gnst.image, (Gnst.rect.left, ALTO // 9))
        ventana.blit(Salir.image, (ANCHO - 150, ALTO - 100))
        pygame.draw.rect(ventana, NEGRO, (ANCHO // 2 - 200, ALTO // 2 - 100, 401, 201))

        # PUNTOSMAX
        puntitos = pygame.font.SysFont('Arial', 80)
        MAXI = puntitos.render("JUGADOR 2", 1, BLANCO)
        ventana.blit(MAXI, (ANCHO // 2 - 154, ALTO // 2 - 26))
        ventana.blit(Otra.image, (150, ALTO - 100))
        MARCA3 = 0
        MARCA2 = 0


# Dibujar comida
def dibujarComida(ventana, SNAKEEQUIS, SNAKEYE, listaSnake, comidita,estado,listaSnake2,listaSnake3,SNAKEEQUISDOS,SNAKEEQUISTRES,SNAKEYETRES,SNAKEYEDOS):
    global MARCA
    if estado=="jugando1":
        xfood = (randint(30, ANCHO - 40))
        yfood = (randint(ALTO // 5, ALTO - 120))

        if len(lista) < 2:
            if xfood % 10 == 0 and yfood % 10 == 0 and MARCA != 3:
                lista.append(xfood)
                lista.append(yfood)
                for i in listaSnake:
                    if i[0] != lista[0] and i[1] != lista[1]:
                        pygame.draw.rect(ventana, BLANCO, (lista[0], lista[1], 10, 10))
                    else:
                        continue

        elif len(lista) == 2 and SNAKEEQUIS == lista[0] and SNAKEYE == lista[1]:
            comidita += 1
            del lista[0]
            del lista[0]
            MARCA += 1

        xfood = (randint(30, ANCHO - 40))
        yfood = (randint(ALTO // 5, ALTO - 120))
        if len(lista) == 0:
            if xfood % 10 == 0 and yfood % 10 == 0 and MARCA != 3:
                lista.append(xfood)
                lista.append(yfood)
                for i in listaSnake:
                    if i[0] != lista[0] and i[1] != lista[1]:
                        pygame.draw.rect(ventana, BLANCO, (lista[0], lista[1], 10, 10))
                    else:
                        continue



# Dibujar y definir boost
def boost(ventana,COLOR):
    if MARCA ==1:
        pygame.draw.rect(ventana, COLOR, (160, ALTO - 90, 80, 60))
    elif MARCA ==2:
        pygame.draw.rect(ventana, COLOR, (160, ALTO - 90, 80, 60))
        pygame.draw.rect(ventana, COLOR, (250, ALTO - 90, 80, 60))
    elif MARCA ==3:
        pygame.draw.rect(ventana, COLOR, (160, ALTO - 90, 80, 60))
        pygame.draw.rect(ventana, COLOR, (250, ALTO - 90, 80, 60))
        pygame.draw.rect(ventana, COLOR, (340, ALTO - 90, 80, 60))
    else:
        pygame.draw.rect(ventana, NEGRO, (160, ALTO - 90, 80, 60))
        pygame.draw.rect(ventana, NEGRO, (250, ALTO - 90, 80, 60))
        pygame.draw.rect(ventana, NEGRO, (340, ALTO - 90, 80, 60))



def dibujar():
    global MARCA
    global MARCA2
    global MARCA3
    global dir
    global dirIA
    global SNAKEEQUISIA
    global SNAKEYEIA
    global SNAKEEQUIS
    global SNAKEYE
    global SNAKEEQUISDOS
    global SNAKEYEDOS
    global SNAKEEQUISTRES
    global SNAKEYETRES
    global GAMETIME
    global GAMETIME2
    global puntos3
    global puntos2
    global puntos1
    global dir2
    global dir3
    global COLOR
    global puntos
    global puntosMAXI
    listaSnake=[]
    listaSnakeDOS=[]
    listaSnake3=[]
    listaSnake2 = []
    listaSnake22 = []
    listaSnake33 = []

    ticktack=10
    rondita=1
    winner=0
    comidita=0
    # Posicion de fondo
    x = 0

    # Ejemplo del uso de pygame
    pygame.init()   # Inicializa pygame
    ventana = pygame.display.set_mode((ANCHO, ALTO))    # Crea la ventana de dibujo
    reloj = pygame.time.Clock() # Para limitar los fps
    termina = False # Bandera para saber si termina la ejecución

    estado = "menu"

    #Sprite Botones
    # Sprite Un jugador
    imgBtnJugar = pygame.image.load("Jugador.png")
    UnJugador = pygame.sprite.Sprite()
    UnJugador.image = imgBtnJugar
    UnJugador.rect = imgBtnJugar.get_rect()
    UnJugador.rect.left = ANCHO//2 - UnJugador.rect.width//2
    UnJugador.rect.top = ALTO//2 - UnJugador.rect.height//2

    # Sprite Multi
    imgBtnJugar2 = pygame.image.load("Multi.png")
    Multi = pygame.sprite.Sprite()
    Multi.image = imgBtnJugar2
    Multi.rect = imgBtnJugar2.get_rect()
    Multi.rect.left = ANCHO // 2 - Multi.rect.width // 2
    Multi.rect.top = ALTO // 2 - Multi.rect.height // 2

    # Sprite FONDO
    imagenFondo = pygame.image.load("Cuadritos.jpg")
    Fondo = pygame.sprite.Sprite()
    Fondo.image = imagenFondo
    Fondo.rect = imagenFondo.get_rect()
    Fondo.rect.left = ANCHO // 2 - Fondo.rect.width // 2
    Fondo.rect.top = ALTO // 2 - Fondo.rect.height // 2

    # Sprite TITULO
    imagenTitulo = pygame.image.load("CRAZY.png")
    Titulo = pygame.sprite.Sprite()
    Titulo.image = imagenTitulo
    Titulo.rect = imagenTitulo.get_rect()
    Titulo.rect.left = ANCHO // 2 - Titulo.rect.width // 2
    Titulo.rect.top = ALTO // 2 - Titulo.rect.height // 2

    # Sprite Puntos Máximos
    PuntosMax = pygame.image.load("Puntos.jpg")
    Puntos = pygame.sprite.Sprite()
    Puntos.image = PuntosMax
    Puntos.rect = PuntosMax.get_rect()
    Puntos.rect.left = ANCHO // 2 - Puntos.rect.width // 2
    Puntos.rect.top = ALTO // 2 - Puntos.rect.height // 2

    # Sprite Escoge tu color
    escogerColor = pygame.image.load("Escoge.png")
    Escoger = pygame.sprite.Sprite()
    Escoger.image = escogerColor
    Escoger.rect = escogerColor.get_rect()
    Escoger.rect.left = ANCHO // 2 - Escoger.rect.width // 2
    Escoger.rect.top = ALTO // 2 - Escoger.rect.height // 2

    # Sprite Regresar
    Regresar = pygame.image.load("Regreso.png")
    Reg = pygame.sprite.Sprite()
    Reg.image = Regresar
    Reg.rect = Regresar.get_rect()
    Reg.rect.left = ANCHO // 2 - Reg.rect.width // 2
    Reg.rect.top = ALTO // 2 - Reg.rect.height // 2

    # Sprite Salir
    Sal = pygame.image.load("Salir.png")
    Salir = pygame.sprite.Sprite()
    Salir.image = Sal
    Salir.rect = Sal.get_rect()
    Salir.rect.left = ANCHO // 2 - Salir.rect.width // 2
    Salir.rect.top = ALTO // 2 - Salir.rect.height // 2

    # Sprite Jugador 1
    Jugador1 = pygame.image.load("Uno.png")
    Uno = pygame.sprite.Sprite()
    Uno.image = Jugador1
    Uno.rect = Jugador1.get_rect()
    Uno.rect.left = ANCHO // 2 - Uno.rect.width // 2
    Uno.rect.top = ALTO // 2 - Uno.rect.height // 2

    # Sprite Jugador 2
    Jugador2 = pygame.image.load("Dos.png")
    Dos = pygame.sprite.Sprite()
    Dos.image = Jugador2
    Dos.rect = Jugador2.get_rect()
    Dos.rect.left = ANCHO // 2 - Dos.rect.width // 2
    Dos.rect.top = ALTO // 2 - Dos.rect.height // 2

    # Sprite Ganador
    Ganador = pygame.image.load("ganador.png")
    Gana = pygame.sprite.Sprite()
    Gana.image = Ganador
    Gana.rect = Ganador.get_rect()
    Gana.rect.left = ANCHO // 2 - Gana.rect.width // 2
    Gana.rect.top = ALTO // 2 - Gana.rect.height // 2

    # Sprite Jugar otra Vez
    Otro = pygame.image.load("otravez.png")
    Otra = pygame.sprite.Sprite()
    Otra.image = Otro
    Otra.rect = Otro.get_rect()
    Otra.rect.left = ANCHO // 2 - Otra.rect.width // 2
    Otra.rect.top = ALTO // 2 - Otra.rect.height // 2

    # Sprite Continuar
    Cont = pygame.image.load("continuar.png")
    Continu = pygame.sprite.Sprite()
    Continu.image = Cont
    Continu.rect = Cont.get_rect()
    Continu.rect.left = ANCHO // 2 - Continu.rect.width // 2
    Continu.rect.top = ALTO // 2 - Continu.rect.height // 2

    # Sprite GANASTE
    Ganador = pygame.image.load("gan.png")
    Gnst = pygame.sprite.Sprite()
    Gnst.image = Ganador
    Gnst.rect = Ganador.get_rect()
    Gnst.rect.left = ANCHO // 2 - Gnst.rect.width // 2
    Gnst.rect.top = ALTO // 2 - Gnst.rect.height // 2

    # Sprite PERDISTE
    Perdedor = pygame.image.load("Perd.png")
    Pesdt = pygame.sprite.Sprite()
    Pesdt.image = Perdedor
    Pesdt.rect = Perdedor.get_rect()
    Pesdt.rect.left = ANCHO // 2 - Pesdt.rect.width // 2
    Pesdt.rect.top = ALTO // 2 - Pesdt.rect.height // 2

    # Sprite MEJOR
    Mejor = pygame.image.load("mejor.png")
    Best = pygame.sprite.Sprite()
    Best.image = Mejor
    Best.rect = Mejor.get_rect()
    Best.rect.left = ANCHO // 2 - Best.rect.width // 2
    Best.rect.top = ALTO // 2 - Best.rect.height // 2


    while not termina:
        puntosMAXI = int(len(listaSnake) + (comidita * 10))

        # Procesa los eventos que recibe (TECLADO)
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:  # El usuario hizo click en el botón de salir
                termina = True

            elif evento.type == pygame.MOUSEBUTTONDOWN: # El usuario hizo click
                xm, ym = pygame.mouse.get_pos()
                if estado == "menu":
                    if xm>=182 and xm <= 617 and ym>=226 and ym <= 310:
                        # Cambiar de ventana
                        estado = "seleccion"
                        x=0
                    elif xm>=154 and xm <= +154+492 and ym>=386 and ym <= 473:
                        # Cambiar de ventana
                        estado = "selecciona"
                        x=0
                    elif xm>=665 and xm <= 792 and ym>=518 and ym <= 556:
                        # Cambiar de ventana
                        termina=True

                elif estado=="seleccion":
                    if xm >= 160 and xm <= 240 and ym >=260 and ym <= 340:
                        # Cambiar de ventana
                        COLOR = ROSA
                        estado = "jugando1"
                    elif xm >= 260 and xm <= 340 and ym >=260 and ym <= 340:
                        # Cambiar de ventana
                        COLOR = ROJO
                        estado = "jugando1"
                    elif xm >= 360 and xm <= 440 and ym >=260 and ym <= 340:
                        # Cambiar de ventana
                        COLOR = AMARILLOCLARO
                        estado = "jugando1"
                    elif xm >= 460 and xm <= 540 and ym >=260 and ym <= 340:
                        # Cambiar de ventana
                        COLOR = VERDE
                        estado = "jugando1"
                    elif xm >= 560 and xm <= 640 and ym >=260 and ym <= 340:
                        # Cambiar de ventana
                        COLOR = AZUL
                        estado = "jugando1"
                    elif xm >= 665 and xm <= 792 and ym >= 518 and ym <= 556:
                        # Cambiar de ventana
                        estado = "menu"
                        x = 0
                elif estado=="selecciona":
                    if xm >= 160 and xm <= 240 and ym >=200 and ym <= 280:
                        # Cambiar de ventana
                        COLOR = ROSA
                        estado = "selecciona2"

                    elif xm >= 260 and xm <= 340 and ym >=200 and ym <= 280:
                        # Cambiar de ventana
                        COLOR = ROJO
                        estado = "selecciona2"

                    elif xm >= 360 and xm <= 440 and ym >=200 and ym <= 280:
                        # Cambiar de ventana
                        COLOR = AMARILLOCLARO
                        estado = "selecciona2"

                    elif xm >= 460 and xm <= 540 and ym >=200 and ym <= 280:
                        # Cambiar de ventana
                        COLOR = VERDE
                        estado = "selecciona2"


                    elif xm >= 560 and xm <= 640 and ym >=200 and ym <= 280:
                        # Cambiar de ventana
                        COLOR = AZUL
                        estado = "selecciona2"
                    elif xm >= 665 and xm <= 792 and ym >= 518 and ym <= 556:
                        # Cambiar de ventana
                        estado = "menu"
                        x = 0
                elif estado=="selecciona2":

                    if COLOR == ROSA:
                        if xm >= 210 and xm <= 290 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = ROJO
                            estado = "jugando2"


                        elif xm >= 310 and xm <= 390 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = AMARILLOCLARO
                            estado = "jugando2"


                        elif xm >= 410 and xm <= 490 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = VERDE
                            estado = "jugando2"


                        elif xm >= 510 and xm <= 590 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = AZUL
                            estado = "jugando2"

                    if COLOR == ROJO:
                        if xm >= 210 and xm <= 290 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = ROSA
                            estado = "jugando2"


                        elif xm >= 310 and xm <= 390 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = AMARILLOCLARO
                            estado = "jugando2"



                        elif xm >= 410 and xm <= 490 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = VERDE
                            estado = "jugando2"


                        elif xm >= 510 and xm <= 590 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = AZUL
                            estado = "jugando2"

                    if COLOR == AMARILLOCLARO:
                        if xm >= 210 and xm <= 290 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = ROSA
                            estado = "jugando2"


                        elif xm >= 310 and xm <= 390 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = ROJO
                            estado = "jugando2"



                        elif xm >= 410 and xm <= 490 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = VERDE
                            estado = "jugando2"


                        elif xm >= 510 and xm <= 590 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = AZUL
                            estado = "jugando2"
                    if COLOR == VERDE:
                        if xm >= 210 and xm <= 290 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = ROSA
                            estado = "jugando2"


                        elif xm >= 310 and xm <= 390 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = ROJO
                            estado = "jugando2"


                        elif xm >= 410 and xm <= 490 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = AMARILLOCLARO
                            estado = "jugando2"


                        elif xm >= 510 and xm <= 590 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = AZUL
                            estado = "jugando2"
                    if COLOR == AZUL:
                        if xm >= 210 and xm <= 290 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = ROSA
                            estado = "jugando2"


                        elif xm >= 310 and xm <= 390 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = ROJO
                            estado = "jugando2"


                        elif xm >= 410 and xm <= 490 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = AMARILLOCLARO
                            estado = "jugando2"

                        elif xm >= 510 and xm <= 590 and ym >= 400 and ym <= 480:
                            # Cambiar de ventana
                            COLOR2 = VERDE
                            estado = "jugando2"

                    if xm >= 512 and xm <= 774 and ym >= 514 and ym <= 556:
                        # Cambiar de ventana
                        estado = "selecciona"
                        x = 0
                elif estado == "jugando1":
                    if xm >= 665 and xm <= 792 and ym >= 518 and ym <= 556:


                        # Cambiar de ventana
                        listaSnake=[]
                        listaSnake2=[]
                        listaIA2=[]
                        listaIA=[]
                        GAMETIME=0
                        SNAKEEQUIS = ANCHO // 2 - 40
                        SNAKEYE = ALTO // 2
                        dir=1
                        MARCA=0
                        comidita=0
                        estado = "menu"
                elif estado == "jugando2":
                    if xm >= 665 and xm <= 792 and ym >= 518 and ym <= 556:
                        # Cambiar de ventana
                        listaSnake2 = []
                        listaSnake22 = []
                        listaSnake3 = []
                        listaSnake33 = []

                        GAMETIME2 = 0
                        SNAKEEQUISDOS = ANCHO // 2 - 40
                        SNAKEYEDOS = ALTO // 2
                        SNAKEEQUISTRES = ANCHO // 2 + 30
                        SNAKEYETRES= ALTO // 2
                        dir2 = 1
                        dir3 = 1
                        MARCA2 = 0
                        MARCA3 = 0
                        rondita=1
                        estado = "menu"
                elif estado=="ganador":


                    if rondita!=3:
                        if xm >= 236 and xm <= 565 and ym >= 518 and ym <= 556:

                            # Cambiar de ventana
                            estado = "jugando1"
                            listaSnake = []
                            listaSnake2 = []
                            lista = []
                            MARCA = 0
                            comidita = 0
                            SNAKEEQUIS = ANCHO // 2 - 40
                            SNAKEYE = ALTO // 2
                            puntosMAXI=0

                            dirIA = 0
                            dir = 1
                            GAMETIME = 0
                            if rondita == 3:
                                rondita = 1
                            else:
                                rondita += 1
                            GAMETIME = 0

                    elif rondita == 3:
                        if xm >= 164 and xm <= 662 and ym >= 512 and ym <= 564:

                            rondita += 1
                            GAMETIME = 0
                            puntosMAXI = 0
                            estado = "jugando1"
                            listaSnake = []
                            listaSnake2 = []

                            lista = []
                            MARCA = 0
                            comidita = 0
                            SNAKEEQUIS = ANCHO // 2 - 40
                            SNAKEYE = ALTO // 2
                            SNAKEEQUISIA = ANCHO // 2 + 30
                            SNAKEYEIA = ALTO // 2
                            dirIA = 0
                            dir = 1

                            rondita = 1


                    if xm >= 665 and xm <= 792 and ym >= 518 and ym <= 556:

                        # Cambiar de valores y ventana
                        listaSnake=[]
                        listaSnake2=[]

                        GAMETIME=0
                        SNAKEEQUIS = ANCHO // 2 - 40
                        SNAKEYE = ALTO // 2
                        SNAKEEQUISIA = ANCHO // 2 + 30
                        SNAKEYEIA = ALTO // 2
                        dirIA=0
                        dir=1
                        rondita=1
                        comidita=0
                        puntosMAXI=0
                        lista = []

                        estado = "menu"

                elif estado=="ganador2":

                    if rondita!=3:
                        if xm >= 236 and xm <= 565 and ym >= 518 and ym <= 556:



                            # Cambiar de ventana
                            estado = "jugando2"
                            listaSnake = []
                            listaSnakeDOS = []
                            listaSnake3 = []
                            listaSnake2 = []
                            listaSnake22 = []
                            listaSnake33 = []

                            GAMETIME2 = 0
                            SNAKEEQUISDOS = ANCHO // 2 - 40
                            SNAKEYEDOS = ALTO // 2
                            SNAKEEQUISTRES = ANCHO // 2 + 30
                            SNAKEYETRES = ALTO // 2
                            dir2 = 1
                            dir3 = 1
                            if rondita == 3:
                                rondita = 1
                            else:
                                rondita += 1
                            GAMETIME = 0

                    elif rondita == 3:
                        if xm >= 164 and xm <= 662 and ym >= 512 and ym <= 564:

                            estado = "jugando2"
                            listaSnake = []
                            listaSnakeDOS = []
                            listaSnake3 = []
                            listaSnake2 = []
                            listaSnake22 = []
                            listaSnake33 = []

                            GAMETIME2 = 0
                            SNAKEEQUISDOS = ANCHO // 2 - 40
                            SNAKEYEDOS = ALTO // 2
                            SNAKEEQUISTRES = ANCHO // 2 + 30
                            SNAKEYETRES = ALTO // 2
                            dir2 = 1
                            dir3 = 1

                            GAMETIME = 0
                            MARCA2=0
                            MARCA3=0
                            rondita = 1

                        if MARCA2==2:
                            if xm >= 164 and xm <= 662 and ym >= 512 and ym <= 564:

                                estado = "jugando2"
                                listaSnake = []
                                listaSnakeDOS = []
                                listaSnake3 = []
                                listaSnake2 = []
                                listaSnake22 = []
                                listaSnake33 = []

                                GAMETIME2 = 0
                                SNAKEEQUISDOS = ANCHO // 2 - 40
                                SNAKEYEDOS = ALTO // 2
                                SNAKEEQUISTRES = ANCHO // 2 + 30
                                SNAKEYETRES = ALTO // 2
                                dir2 = 1
                                dir3 = 1

                                GAMETIME = 0
                                MARCA2 = 0
                                MARCA3 = 0
                                rondita = 1

                        elif MARCA3==2:
                            if xm >= 164 and xm <= 662 and ym >= 512 and ym <= 564:

                                estado = "jugando2"
                                listaSnake = []
                                listaSnakeDOS = []
                                listaSnake3 = []
                                listaSnake2 = []
                                listaSnake22 = []
                                listaSnake33 = []
                                GAMETIME2 = 0
                                SNAKEEQUISDOS = ANCHO // 2 - 40
                                SNAKEYEDOS = ALTO // 2
                                SNAKEEQUISTRES = ANCHO // 2 + 30
                                SNAKEYETRES = ALTO // 2
                                dir2 = 1
                                dir3 = 1
                                GAMETIME = 0
                                MARCA2 = 0
                                MARCA3 = 0
                                rondita = 1

                    if xm >= 665 and xm <= 792 and ym >= 518 and ym <= 556:
                        # Cambiar de ventana
                        listaSnake = []
                        listaSnakeDOS = []
                        listaSnake3 = []
                        listaSnake2 = []
                        listaSnake22 = []
                        listaSnake33 = []

                        GAMETIME2 = 0
                        SNAKEEQUISDOS = ANCHO // 2 - 40
                        SNAKEYEDOS = ALTO // 2
                        SNAKEEQUISTRES = ANCHO // 2 + 30
                        SNAKEYETRES = ALTO // 2
                        dir2 = 1
                        dir3 = 1
                        MARCA2 = 0
                        MARCA3 = 0
                        rondita=1
                        estado = "menu"
                    if MARCA2>=2 or MARCA3>=2:
                        rondita=1
                        MARCA2=0
                        MARCA3=0

            elif evento.type == pygame.MOUSEBUTTONUP:  # El usuario dejo de hacer click
                pass

            elif evento.type==pygame.KEYDOWN: # El usuario presionó una tecla
                if estado=="menu":
                    pass
                elif estado=="jugando1":

                    if evento.key == 273 and dir != 90:  # El usuario presiona flecha abajo
                        dir = 270
                    elif evento.key == 274 and dir != 270:  # El usuario presiona flecha arriba
                        dir = 90
                    elif evento.key == 275 and dir != 180:  # El usuario presiona flecha derecha
                        dir = 0
                    elif evento.key == 276 and dir != 0:  # El usuario presiona flecha izquierda
                        dir = 180

                    elif evento.unicode == 'r' and MARCA == 3:
                        comidita+=10
                        MARCA=0


                elif estado=="jugando2":
                    if evento.key == 273 and dir2 != 90:  # El usuario presiona flecha abajo
                        dir2 = 270
                    elif evento.key == 274 and dir2 != 270:  # El usuario presiona flecha arriba
                        dir2 = 90
                    elif evento.key == 275 and dir2 != 180:  # El usuario presiona flecha derecha
                        dir2 = 0
                    elif evento.key == 276 and dir2 != 0:  # El usuario presiona flecha izquierda
                        dir2 = 180

                    if evento.unicode == "s" and dir3 != 90:  # El usuario presiona flecha abajo
                        dir3 = 270
                    elif evento.unicode == "w" and dir3 != 270:  # El usuario presiona flecha arriba
                        dir3 = 90
                    elif evento.unicode == "d" and dir3 != 180:  # El usuario presiona flecha derecha
                        dir3 = 0
                    elif evento.unicode == "a" and dir3 != 0:  # El usuario presiona flecha izquierda
                        dir3 = 180
            elif evento.type == pygame.KEYUP:  # El usuario dejó de presionar una tecla
                pass

        # Dibujar, aquí haces todos los trazos que requieras
        if estado == "menu":

            ventana.blit(Fondo.image, (x, Fondo.rect.top))
            ventana.blit(Fondo.image, (ANCHO + x, Fondo.rect.top))
            dibujarMenu(ventana,Multi,UnJugador,Titulo,Puntos,Salir)
            marcadores(ventana, listaSnake, listaSnakeDOS, MARCA, estado, COLOR,rondita,comidita,listaSnake3,MARCA2,MARCA3)

            x -= 3

            if x <= -ANCHO:
                x = 0
        elif estado=="seleccion":

            ventana.blit(Fondo.image, (x, Fondo.rect.top))
            ventana.blit(Fondo.image, (ANCHO + x, Fondo.rect.top))
            datosJugador(ventana, Escoger,Salir)

            x -= 3

            if x <= -ANCHO:
                x = 0
        elif estado == "selecciona":

            ventana.blit(Fondo.image, (x, Fondo.rect.top))
            ventana.blit(Fondo.image, (ANCHO + x, Fondo.rect.top))
            datosJugador2(ventana, Escoger,Salir,Uno)

            x -= 3

            if x <= -ANCHO:
                x = 0
        elif estado == "selecciona2":

            ventana.blit(Fondo.image, (x, Fondo.rect.top))
            ventana.blit(Fondo.image, (ANCHO + x, Fondo.rect.top))
            datosJugador3(ventana, Escoger,COLOR,Reg,Uno,Dos)

            x -= 3

            if x <= -ANCHO:
                x = 0
        elif estado == "jugando1":

            if GAMETIME == 0:
                ventana.fill(NEGRO)
                dibujarJugando1(ventana, COLOR,Salir)
                dirIA = 3 # randint(1, 4)
                # pygame.draw.rect(ventana, BLANCO, (SNAKEEQUISIA + 1, SNAKEYEIA + 1, 9, 9))

                marcadores(ventana, listaSnake, listaSnakeDOS, MARCA, estado, COLOR, rondita,comidita,listaSnake3,MARCA2,MARCA3)

            GAMETIME += 1

            dibujarSnake(ventana,dir,COLOR,listaSnake,listaSnake2,rondita,estado)
            # IA(ventana,listaSnake,dirIA,listaIA,listaIA2,dir)

            dibujarComida(ventana, SNAKEEQUIS, SNAKEYE, listaSnake, comidita,estado,listaSnake2,listaSnake3,SNAKEEQUISDOS,SNAKEEQUISTRES,SNAKEYETRES,SNAKEYEDOS)
            boost(ventana,COLOR)
            marcadores(ventana, listaSnake, listaSnakeDOS, MARCA, estado, COLOR,rondita,comidita,listaSnake3,MARCA2,MARCA3)

            if dir != 1:
                listaSnake.append([SNAKEEQUIS, SNAKEYE])
                listaSnake2 = listaSnake[:]
                listaSnake2.reverse()
                del listaSnake2[0]

            if len(listaSnake) > 3:
                for i in listaSnake2:
                    if i[0] == SNAKEEQUIS and i[1] == SNAKEYE:
                        winner=2
                        if rondita == 1:
                            puntos1 = puntosMAXI
                        if rondita == 2:
                            puntos2 = puntosMAXI
                        if rondita == 3:
                            puntos3 = puntosMAXI

                            if puntos3 > puntos2 and puntos3 > puntos1:
                                puntosMAXI = puntos3
                            if puntos2 > puntos1 and puntos2 > puntos3:
                                puntosMAXI = puntos2
                            else:
                                puntosMAXI = puntos1

                            for i in contenido:

                                nuevo = open("puntosMaximos.txt", "w", encoding='UTF-8')
                                nuevo.write(str(puntosMAXI))
                                nuevo.close()

                        estado = "ganador"

                        print(puntos1)
                        print(puntos2)
                        print(puntos3)
                        print(puntosMAXI)







            if SNAKEEQUIS > 760 or SNAKEEQUIS < 30 or SNAKEYE > 480 or SNAKEYE < ALTO // 5:
                winner = 2
                if rondita != 3:
                    if rondita == 1:
                        puntos1 = puntosMAXI
                        puntosMAXI = 0
                    if rondita == 2:
                        puntos2 = puntosMAXI
                        puntosMAXI = 0

                if rondita == 3:
                    puntos3 = puntosMAXI
                    if puntos3 > puntos2 and puntos3 > puntos1:
                        puntosMAXI = puntos3
                    if puntos2 > puntos1 and puntos2 > puntos3:
                        puntosMAXI = puntos2
                    else:
                        puntosMAXI = puntos1
                    puntos = 0

                    for i in contenido:
                        puntospasados = int(i)
                        nuevo = open("puntosMaximos.txt", "w", encoding='UTF-8')
                        if puntosMAXI > puntospasados:
                            nuevo.write(str(puntosMAXI))
                            nuevo.close()
                estado = "ganador"

        elif estado == "jugando2":


            if GAMETIME2 == 0:
                ventana.fill(NEGRO)
                dibujarJugando2(ventana, COLOR, COLOR2, Salir)
                marcadores(ventana, listaSnake, listaSnakeDOS, MARCA, estado, COLOR, rondita,comidita,listaSnake3,MARCA2,MARCA3)

            GAMETIME2 += 1

            dibujarComida(ventana, SNAKEEQUIS, SNAKEYE, listaSnake, comidita,estado,listaSnakeDOS,listaSnake3,SNAKEEQUISDOS,SNAKEEQUISTRES,SNAKEYETRES,SNAKEYEDOS)
            dibujarSnake2(ventana,dir2 ,dir3, COLOR2,COLOR,rondita)
            marcadores(ventana, listaSnake, listaSnakeDOS, MARCA, estado, COLOR,rondita,comidita,listaSnake3,MARCA2,MARCA3)

            if dir2 != 1:
                listaSnakeDOS.append([SNAKEEQUISDOS,SNAKEYEDOS])
                listaSnake22 = listaSnakeDOS[:]
                listaSnake22.reverse()
                del listaSnake22[0]

            if len(listaSnakeDOS) > 3:
                for i in listaSnake22:
                    if i[0] == SNAKEEQUISDOS and i[1] == SNAKEYEDOS:
                        winner=3
                        MARCA3 += 1
                        estado = "ganador2"
                        print(puntos)


            if dir3 != 1:
                listaSnake3.append([SNAKEEQUISTRES, SNAKEYETRES])
                listaSnake33 = listaSnake3[:]
                listaSnake33.reverse()
                del listaSnake33[0]


            if len(listaSnake3) > 3:
                for i in listaSnake33:
                    if i[0] == SNAKEEQUISTRES and i[1] == SNAKEYETRES:
                        winner=1
                        MARCA2 += 1

                        estado = "ganador2"
                        print(puntos)

            if len(listaSnake3) > 3:
                for i in listaSnake22:
                    if i[0] == SNAKEEQUISTRES and i[1] == SNAKEYETRES:
                        winner=1
                        MARCA2 += 1

                        estado = "ganador2"
                        print(puntos)
            if len(listaSnake3) > 3:
                for i in listaSnake33:
                    if i[0] == SNAKEEQUISDOS and i[1] == SNAKEYEDOS:
                        winner=3
                        MARCA3 += 1

                        estado = "ganador2"
                        print(puntos)

            if SNAKEEQUISDOS > 760 or SNAKEEQUISDOS < 30 or SNAKEYEDOS > 480 or SNAKEYEDOS < ALTO // 5:
                winner = 3
                estado = "ganador2"
                MARCA3+=1
            if SNAKEEQUISTRES > 760 or SNAKEEQUISTRES < 30 or SNAKEYETRES > 480 or SNAKEYETRES < ALTO // 5:
                winner = 1
                MARCA2 += 1
                estado = "ganador2"





        elif estado=="ganador":
            ganador(ventana,Gana,Salir,Otra,rondita,Continu,Pesdt,Gnst,winner,Best,estado,puntosMAXI,MARCA2,MARCA3)


        elif estado=="ganador2":
            ganador(ventana,Gana,Salir,Otra,rondita,Continu,Pesdt,Gnst,winner,Best,estado,puntosMAXI,MARCA2,MARCA3)





        pygame.display.flip()   # Actualiza trazos
        reloj.tick(ticktack)         # 40 fps

    pygame.quit()   # termina pygame


def main():
    dibujar()


main()